'use strict';

module.exports = {
    SECRET: 'my secret',
    DATABASE_URL: 'mongodb://mongodb-dev-3.originem.3543.mongodbdns.com:27000/originem-dev',
	 // DATABASE_URL: 'mongodb://localhost/originem-dev',
 JWT_SECRET: '23ofsdguoib2FG3iugb',
 AWS_ACCESS_KEY : 'AKIAIF5NQNWWX4EY5ATA',
 AWS_SECRET_KEY : '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',
 S3_BUCKET : 'originem-payroll-dev',
 S3_P45_FOLDER:'P45/',
    S3_P45_TEMP_FOLDER: 'P45/temp/',
    S3_AVATARS_FOLDER: 'Avatars/',
 FROM_ADDRESS:'system@originem.co.uk',
 SMTP_HOST:'email-smtp.eu-west-1.amazonaws.com',
 SMTP_SOCKET_TIMEOUT:5000,
    SMTP_PORT: 2587,
    SMTP_USERNAME: 'AKIAIBHAVELEOK6IY45Q',
    SMTP_PASSWORD: 'AgUx7ols+tm69kRoqAGcft7qz0IYn/Mi7D4pP6zTdIwJ',
    TEMP_DIR: '/temp'
};